<?php 
$mysql_hostname = "localhost";
$mysql_user = "wwwquakb_main";
$mysql_password = "uB#{(J;6rQ-o";
$mysql_database = "wwwquakb_maindb";
$prefix = "";
$base_url = 'https://quakbox.com/';
$homepage = "https://quakbox.com/home";
$logo = "/home/wwwquakb/public_html/images/quack.png";
$logo1 = "/home/wwwquakb/public_html/images/email.jpg";
$root_folder_path="/home/wwwquakb/";
$site_name="Quakbox";
$site_email="noreply@quakbox.com";
$site_notification_email="notification@quakbox.com";
$site_landing='https://quakbox.com/landing.php';

// Under constraction Page
//$site_landing='https://quakbox.com/CommingSoon/index.html';


$con = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password);

if(!defined('QB_CONFIG')){
    define('QB_CONFIG', true);
} else {
    return;
}

error_reporting(-1);

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  
mysqli_select_db($con, $mysql_database) or die("Could not select database!");

//$dbh = new PDO("mysql:host=$mysql_hostname;dbname=$mysql_database",$mysql_user,$mysql_password);

include_once "/home/wwwquakb/public_html/assets/security/secureQuakb.php";

function randomCode($length){
		$random= "";
		srand((double)microtime()*1000000);
		$data = "AbcDE123IJKLMN67QRSTUVWXYZ";
		$data .= "aBCdefghijklmn123opq45rs67tuv89wxyz";
		$data .= "0FGH45OP89";
		for($i = 0; $i < $length; $i++){
		$random .= substr($data, (rand()%(strlen($data))), 1);
		}
		return $random;
	}
	function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}

function curPageName() {
 return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
}
include_once '/home/wwwquakb/public_html/includes/mobile-detect.php';
 $mobile = Detect_mobile();
 if ($mobile === true){
	//header("Location:https://m.quakbox.com/"); 
 }